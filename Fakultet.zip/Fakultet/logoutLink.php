<?php

echo "<a href=\"logout.php\">Logout</a>";